rm -f loader/BasicFilename.tif
