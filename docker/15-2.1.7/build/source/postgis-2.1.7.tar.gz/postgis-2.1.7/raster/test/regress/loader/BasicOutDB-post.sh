rm -f loader/BasicOutDB.tif
rm -f loader/BasicOutDB.opts
