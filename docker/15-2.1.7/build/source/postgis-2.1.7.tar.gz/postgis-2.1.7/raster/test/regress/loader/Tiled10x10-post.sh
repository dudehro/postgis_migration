rm -f loader/Tiled10x10.tif
