select ST_Asewkt(the_geom::geometry) from loadedshp order by 1;
